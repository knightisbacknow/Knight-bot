
/**
 * Copyright (c) 2023-2025 Cortex Realm | Made by Friday
 * Join Support Server: https://discord.gg/EWr3GgP6fe
 */

import { Collection } from 'discord.js';

// Default prefix - you can make this configurable per guild later
const DEFAULT_PREFIX = '&';

/**
 * Parse command arguments from message content
 */
function parseArgs(content, commandName) {
  const args = content.slice(DEFAULT_PREFIX.length + commandName.length).trim().split(/ +/);
  return args.filter(arg => arg.length > 0);
}

/**
 * Create a mock interaction object for prefix commands
 */
function createMockInteraction(message, commandName, args) {
  const mockInteraction = {
    // Basic properties
    user: message.author,
    member: message.member,
    guild: message.guild,
    channel: message.channel,
    channelId: message.channel.id,
    guildId: message.guild?.id,
    client: message.client,
    
    // Reply functionality
    replied: false,
    deferred: false,
    
    // Mock options based on command
    options: {
      getString: (name) => {
        switch (commandName) {
          case 'chat':
            return name === 'message' ? args.join(' ') : null;
          case 'setup-channel':
            return name === 'channel' ? args[0] : null;
          case 'remove-channel':
            return name === 'channel' ? args[0] : null;
          default:
            return args[0] || null;
        }
      },
      getChannel: (name) => {
        if (args[0]) {
          // Try to parse channel mention or ID
          const channelId = args[0].replace(/[<#>]/g, '');
          return message.guild?.channels.cache.get(channelId) || null;
        }
        return null;
      },
      getUser: (name) => {
        if (args[0]) {
          // Try to parse user mention or ID
          const userId = args[0].replace(/[<@!>]/g, '');
          return message.guild?.members.cache.get(userId)?.user || null;
        }
        return null;
      }
    },
    
    // Reply methods
    reply: async (options) => {
      mockInteraction.replied = true;
      if (typeof options === 'string') {
        return await message.reply(options);
      }
      return await message.reply(options);
    },
    
    editReply: async (options) => {
      // For prefix commands, we'll send a new message instead of editing
      if (typeof options === 'string') {
        return await message.channel.send(options);
      }
      return await message.channel.send(options);
    },
    
    deferReply: async () => {
      mockInteraction.deferred = true;
      // Send typing indicator for prefix commands
      await message.channel.sendTyping();
    },
    
    followUp: async (options) => {
      if (typeof options === 'string') {
        return await message.channel.send(options);
      }
      return await message.channel.send(options);
    }
  };
  
  return mockInteraction;
}

/**
 * Handle prefix commands
 */
export async function handlePrefixCommand(message, client) {
  const content = message.content.trim();
  
  // Check if message starts with prefix
  if (!content.startsWith(DEFAULT_PREFIX)) return false;
  
  // Extract command name
  const args = content.slice(DEFAULT_PREFIX.length).trim().split(/ +/);
  const commandName = args.shift()?.toLowerCase();
  
  if (!commandName) return false;
  
  // Check if command exists
  const command = client.commands.get(commandName);
  if (!command) return false;
  
  try {
    // Create mock interaction
    const mockInteraction = createMockInteraction(message, commandName, args);
    
    // Validate required options for specific commands
    if (commandName === 'chat,c' && args.length === 0) {
      await message.reply('Please provide a message to chat with the AI. Usage: `&chat <your message here>`');
      return true;
    }
    
    if ((commandName === 'setup-channel,setup,sc' || commandName === 'remove-channel,rc') && args.length === 0) {
      await message.reply(`Please specify a channel. Usage: \`&${commandName} #channel\``);
      return true;
    }
    
    // Execute the command
    await command.execute(mockInteraction);
    return true;
    
  } catch (error) {
    console.error(`Error executing prefix command ${commandName}:`, error);
    
    try {
      await message.reply(`An error occurred while executing the command: ${error.message}`);
    } catch (replyError) {
      console.error('Failed to send error message:', replyError);
    }
    
    return true;
  }
}

/**
 * Get command help for prefix usage
 */
export function getPrefixHelp() {
  return {
    prefix: DEFAULT_PREFIX,
    commands: [
      { name: 'chat', usage: `${DEFAULT_PREFIX}chat <your message>`, description: 'Chat with the AI assistant' },
      { name: 'help', usage: `${DEFAULT_PREFIX}help`, description: 'Show command help' },
      { name: 'settings', usage: `${DEFAULT_PREFIX}settings`, description: 'View your AI settings' },
      { name: 'setup-channel', usage: `${DEFAULT_PREFIX}setup-channel #channel`, description: 'Set up AI channel (Admin only)' },
      { name: 'remove-channel', usage: `${DEFAULT_PREFIX}remove-channel #channel`, description: 'Remove AI channel (Admin only)' },
      { name: 'list-channels', usage: `${DEFAULT_PREFIX}list-channels`, description: 'List AI channels (Admin only)' },
      { name: 'clear', usage: `${DEFAULT_PREFIX}clear`, description: 'Clear conversation history' }
    ]
  };
}

export default {
  handlePrefixCommand,
  getPrefixHelp,
  DEFAULT_PREFIX
};
