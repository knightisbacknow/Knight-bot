/**
 * Copyright (c) 2023-2025 Cortex Realm | Made by Friday
 * Join Support Server: https://discord.gg/EWr3GgP6fe
 */

import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription('Display information about bot commands and features');

// Function to get prefix information (assuming it's defined elsewhere)
function getPrefixHelp() {
    return {
        prefix: '!' // Replace with your actual prefix retrieval logic
    };
}

export async function execute(interaction) {
    // Get prefix command information
    const prefixHelp = getPrefixHelp();

    // Create embed with command information
    const helpEmbed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('BAZINGA AI ASSISTANT')
      .setDescription('You can use either slash commands (**/**) or prefix commands (**&**)')
      .addFields(
        { 
          name: '💬 AI Chat Commands', 
          value: '> **`/chat [message]`** or **`&chat [message]`** - Chat with the AI assistant\n> **`/clear`** or **`&clear`** - Clear your conversation history'
        },
        { 
          name: '🔧 User Settings', 
          value: '> **`/settings`** or **`&settings`** - Configure your AI preferences' 
        },
        { 
          name: '📋 Channel Management', 
          value: '> **`/setup-channel`** or **`&setup-channel`** - Set up a channel for AI auto-responses\n> **`/remove-channel`** or **`&remove-channel`** - Remove AI from a channel\n> **`/list-channels`** or **`&list-channels`** - List all AI channels in this server' 
        },
        { 
          name: '❓ Help & Info', 
          value: '> **`/help`** - Display this help information' 
        },
        { 
          name: '🔘 Response Buttons', 
          value: '> 🔄 **Regenerate**: Create a new response\n> ➕ **Continue**: Continue the response\n> 💾 **Save**: Save the response\n> 🗑️ **Delete**: Delete the message' 
        },
        {
          name: '📝 Using AI Channels',
          value: '> Once a channel is set up with `setup-channel`, the AI will automatically respond to messages based on your configured probability. Auto-responses work alongside manual `/chat` commands.'
        },
        {
          name: 'ℹ️ About',
          value: '> This bot uses the Groq AI API (Llama-3 model) for fast and free AI responses.'
        },
        { 
          name: '📝 Prefix Usage Examples', 
          value: `> \`&chat Hello AI!\`\n> \`&setup-channel #ai-chat\`\n> \`&settings\``, inline: false 
        }
      )
      .setFooter({ 
        text: 'BZ KNIGHT AI Assistant | Made by Knight',
        iconURL: interaction.client.user.displayAvatarURL()
      })
      .setTimestamp();

    await interaction.reply({
      embeds: [helpEmbed],
      ephemeral: false,
    });
}