import { SlashCommandBuilder } from 'discord.js';
import { createLoadingEmbed, createErrorEmbed, createActionButtons } from '../utils/embedUtils.js';
import { generateChatCompletion } from '../services/groqService.js';
import User from '../models/User.js';
import Conversation from '../models/Conversation.js';

export const data = new SlashCommandBuilder()
  .setName('chat')
  .setDescription('Chat with the AI assistant')
  .addStringOption(option =>
    option.setName('message')
      .setDescription('Your message to the AI')
      .setRequired(true));

export async function execute(interaction) {
  try {
    // Defer reply to give time for AI processing
    await interaction.deferReply();

    const userMessage = interaction.options.getString('message');
    const userId = interaction.user.id;
    const channelId = interaction.channelId;
    const username = interaction.user.username;

    // Add timeout for database operations
    const dbTimeout = 8000; // 8 seconds timeout
    
    let user, conversation;
    
    try {
      // Get or create user in database with timeout
      user = await Promise.race([
        User.findOrCreateUser(userId, username),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Database operation timed out')), dbTimeout)
        )
      ]);
      
      // Get or create conversation with timeout
      conversation = await Promise.race([
        Conversation.getOrCreateConversation(userId, channelId),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Database operation timed out')), dbTimeout)
        )
      ]);
      
      // Add the user's message to the conversation
      await conversation.addMessage('user', userMessage);
      
    } catch (dbError) {
      console.error('Database error:', dbError);
      // Fallback: use default settings if database is unavailable
      user = { 
        settings: { 
          aiModel: 'mixtral-8x7b-32768', 
          temperature: 0.7, 
          maxTokens: 1000 
        } 
      };
      conversation = { 
        getFormattedMessages: () => [{ role: 'user', content: userMessage }],
        addMessage: () => Promise.resolve()
      };
    }
    
    // Generate AI response using formatted messages
    const aiResponse = await generateChatCompletion(conversation.getFormattedMessages(), {
      model: user.settings.aiModel,
      temperature: user.settings.temperature,
      maxTokens: user.settings.maxTokens,
    });
    
    // Try to add the AI's response to the conversation
    try {
      await conversation.addMessage('assistant', aiResponse);
    } catch (dbError) {
      console.error('Failed to save AI response to database:', dbError);
      // Continue anyway, just don't save to database
    }
    
    // Create action buttons
    const actionRow = createActionButtons();
    
    // Send the response
    await interaction.editReply({
      content: aiResponse,
      components: [actionRow],
    });
    
  } catch (error) {
    console.error('Error in chat command:', error);
    
    try {
      const errorEmbed = createErrorEmbed(`Failed to process your request: ${error.message}`);
      
      if (interaction.deferred) {
        await interaction.editReply({
          embeds: [errorEmbed],
        });
      } else {
        await interaction.reply({
          embeds: [errorEmbed],
          flags: 64
        });
      }
    } catch (replyError) {
      console.error('Failed to send error response:', replyError);
    }
  }
} 